package code_generator.instructions;

public class SystemCall {
	public static Integer print_int = 1;
	public static Integer print_float = 2;
	public static Integer print_string = 4;
	public static Integer read_int = 5;
	public static Integer allocate = 9;
}
