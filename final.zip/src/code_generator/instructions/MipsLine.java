package code_generator.instructions;

public interface MipsLine {
	String toString();
}
