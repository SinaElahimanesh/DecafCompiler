package code_generator;

public enum AssignmentType {
	ASSIGN,
	ADD_ASSIGN,
	SUBTRACT_ASSIGN,
	MULTIPLY_ASSIGN,
	DIVIDE_ASSIGN,
	NONE
}
