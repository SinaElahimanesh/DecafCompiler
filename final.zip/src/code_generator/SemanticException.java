package code_generator;

public class SemanticException extends Exception {
	public SemanticException() {
		super();
	}

	public SemanticException(String message) {
		super(message);
	}
}
