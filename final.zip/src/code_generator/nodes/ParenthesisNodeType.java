package code_generator.nodes;

public enum ParenthesisNodeType {
	CONSTANT,
	THIS,
	EXPRESSION,
	IDENT
}
