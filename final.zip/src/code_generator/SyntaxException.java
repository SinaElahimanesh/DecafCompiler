package code_generator;

public class SyntaxException extends Exception {
	public SyntaxException() {
		super();
	}

	public SyntaxException(String msg) {
		super(msg);
	}
}
