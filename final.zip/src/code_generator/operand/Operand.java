package code_generator.operand;

public interface Operand {
	@Override
	String toString();
}
