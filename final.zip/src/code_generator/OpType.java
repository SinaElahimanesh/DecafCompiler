package code_generator;

public enum OpType {
	ADD,
	SUBTRACT,
	MULTIPLY,
	DIVIDE,
	NONE
}
