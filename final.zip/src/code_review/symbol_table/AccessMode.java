package code_review.symbol_table;

public enum AccessMode {
	PRIVATE,
	PUBLIC,
	NONE
}
