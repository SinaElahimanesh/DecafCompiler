package code_review.symbol_table;

public enum FieldType {
	FUNCTION,
	VARIABLE
}
